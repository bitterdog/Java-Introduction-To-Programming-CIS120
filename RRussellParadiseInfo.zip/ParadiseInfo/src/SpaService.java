// Ronald Russell
// Dr. Fay
// CIS 120
// you Do It ch 3
// 3/2/2020

public class SpaService {

    private String serviceDescription;
    private double price;

    public SpaService(){
        serviceDescription = "xxxx";
        price = 0;
    }
    

    public void setServiceDescription(String serviceDesc){
        serviceDescription = serviceDesc;
    }

    public void setPrice(double prc){
        price = prc;
    }

    public String getServiceDescription(){
        return serviceDescription;
    }

    public double getPrice(){
        return price;
    }

}
