
// Ronald Russell
// Dr. Fay
// CIS 120
// Midterm Exam Count 21
// 3/31/2020




	/*  Two people play the game of Count 21 by taking turns entering a 
	 *  1, 2, or 3, which is added to a running total. The player who add
	 *  the value that makes the total reach or exceed 21 loses the game. 
	 *  Create a game of Count 21 in which a player competes against the computer.
	 *  Program the game to allow either the computer, or the user win the game. */

import java.util.Scanner;



public class Count_21 {

	public static void main(String[] args) 
	{
		// Variables
		int userCount = 0;
		int computerCount = 0;
	    int diceCount = 21;
	    int count = 0;
	    
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Player, please enter 1, 2, or 3 >>> ");
        userCount += keyboard.nextInt();
        computerCount = ((int)(Math.random() * 100) % 5 );
        System.out.println(computerCount);
        System.out.println(userCount);
        while(diceCount == 21)
        {    
         
    
        	// Player inputs 1, 2, or 3 adding to the total 
            
        	
        	System.out.println("Player, please enter 1, 2, or 3 >>> ");
            userCount += keyboard.nextInt();
            
       
            // If players number is >=21 Player wins
            
            if (userCount >= 21) {
                System.out.println("User Wins!! " +userCount);
                break;
            }
            
            // If computer number is >=21 computer wins
            
            computerCount += ((int)(Math.random() * 100) % 5 );
            if (computerCount >= 21) {
                System.out.println("Computer Wins!! " + computerCount);
                break;
            }
            System.out.println(computerCount);
            System.out.println(userCount);
            
        	
        	
        }
	}
}
