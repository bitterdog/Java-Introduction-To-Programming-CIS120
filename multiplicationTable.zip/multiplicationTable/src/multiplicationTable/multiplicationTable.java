package multiplicationTable;

import java.util.Scanner;

// Prints multiplication table 

public class multiplicationTable

{
	
	public static Scanner keyboard = new Scanner(System.in);
     
    public static void main(String[] args) 
    {
    	

    	// User input as to size of multiplication table 1-20. 
    	//I did not put a hard block for 1-20 so if a user puts something larger then 20 this table could get HUGE
    	System.out.print("What number would you like  multiplication table to go to (1-20)? ");

		int arraySize = keyboard.nextInt();
		
		keyboard.nextLine();
    	// builds array based off of the user input of how large they want the table to be
        int tableSize = arraySize;
        
        if (tableSize>20)
        {
        	System.out.println("Sorry, " + tableSize + " will create a table to large");
        }
        
        
        
        printMultiplicationTable(tableSize);
    }
     
    public static void printMultiplicationTable(int tableSize) 
    
    {
    	 System.out.println();
    	//Format output
        // first print the top header row
        System.out.format("      ");
        for(int i = 1; i<=tableSize;i++ ) 
        {
            System.out.format("%4d",i);
        }
        System.out.println();
        System.out.println();
       
         
        for(int i = 1 ;i<=tableSize;i++) 
        {
            // print left most column first
            System.out.format("%4d |",i);
            for(int j=1;j<=tableSize;j++) {
                System.out.format("%4d",i*j);
            }
            System.out.println();
        }
    }
     
}
