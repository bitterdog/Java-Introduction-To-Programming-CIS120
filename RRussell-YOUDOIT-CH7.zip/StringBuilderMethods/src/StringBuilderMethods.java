// Ronald Russell
// Dr. Fay
// CIS 120
// you Do It ch 7
// 4/15/2020



public class StringBuilderMethods


{
 public static void main(String[] args)
 {
	 //create a StringBuilder object, and then display it
		 StringBuilder str = new StringBuilder("singing");
		 System.out.println(str);
	 
	 //add characters to the existing StringBuilder and display it 
		 str.append(" in the dead of ");
		 System.out.println(str);
	 
	 
	 //insert characters. Then display the StringBuilder, insert additional characters, and display it again
		 str.insert(0, "Black");
		 System.out.println(str);
		 str.insert(5, "bird ");
		 System.out.println(str);
		 
	 //Add one more append and display sequence
	 
		 str.append("night");
		 System.out.println(str);

	 
	 
 }
}