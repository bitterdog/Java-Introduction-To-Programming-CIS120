// Ronald Russell
// Dr. Fay
// CIS 120
// you Do It ch 7
// 4/15/2020

import javax.swing.*;

public class RepairName
{
 public static void main(String[] args)
	 {
	 
	 /*
	  * The program declares several variables, including two
		strings that will refer to a name: one will be �repaired� with correct capitalization;
		the other will be saved as the user entered it so it can be displayed in its original
		form at the end of the program. After declaring the variables, prompt the user
		for a name
	  */
			 String name, saveOriginalName;
			 int stringLength;
			 int i;
			 char c;
			 name = JOptionPane.showInputDialog(null,
			 "Please enter your first and last name");
			 
	 /*
	  * Store the name entered in the saveOriginalName variable. Next, calculate the
		length of the name the user entered, then begin a loop that will examine every
		character in the name. The first character of a name is always capitalized, so
		when the loop control variable i is 0, the character in that position in the name
		string is extracted and converted to its uppercase equivalent. Then the name
		is replaced with the uppercase character appended to the remainder of the
		existing name.
	  */
	 
			 saveOriginalName = name;
			 stringLength = name.length();
			 for(i = 0; i < stringLength; i++)
			 {
			  c = name.charAt(i);
			  if(i == 0)
			  {
			  c = Character.toUpperCase(c);
			  name = c + name.substring(1, stringLength);
			  }
		/*
		 *  After the first character in the name is converted, the program looks through
			the rest of the name, testing for spaces and capitalizing every character
			that follows a space. When a space is found at position i, i is increased, the
			next character is extracted from the name, the character is converted to its
			uppercase version, and a new name string is created using the old string up to
			the current position, the newly capitalized letter, and the remainder of the name
			string. The if�else ends and the for loop ends.	 
		 */
			 
			  else
				  if(name.charAt(i) == ' ')
				  {
				  ++i;
				  c = name.charAt(i);
				  c = Character.toUpperCase(c);
				  name = name.substring(0, i) + c +
				  name.substring(i + 1, stringLength);
				  }
				 }
	 
	 /*
	  * After every character has been examined, display the original and repaired
names, and add closing braces for the main() method and the class
	  */
			JOptionPane.showMessageDialog(null, "Original name was " +
			 saveOriginalName + "\nRepaired name is " + name);
 }
 }
 
