import java.util.Scanner;

public class Count21 {

	public static void main(String[] args) 
	{
		int userCount = 0;
		int computerCount = 0;
	    int diceCount = 21;
	    int count = 0;
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Player, please enter 1, 2, or 3 >>> ");
        userCount += keyboard.nextInt();
        computerCount = ((int)(Math.random() * 100) % 5 );
        System.out.println(computerCount);
        System.out.println(userCount);
        while(diceCount == 21)
        {    
         
            System.out.println("Player, please enter 1, 2, or 3 >>> ");
            userCount += keyboard.nextInt();
            if (userCount >= 21) {
                System.out.println("User Wins!! " +userCount);
                break;
            }
            computerCount += ((int)(Math.random() * 100) % 5 );
            if (computerCount >= 21) {
                System.out.println("Computer Wins!! " + computerCount);
                break;
            }
            System.out.println(computerCount);
            System.out.println(userCount);
            
        	
        	
        }
	}
}
