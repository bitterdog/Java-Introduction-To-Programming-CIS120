// Ronald Russell
// Dr. Fay
// CIS 120
// Lab Programming Assignment #6
// 5/5/2020

package employees;

import java.util.Scanner;

public class main 
{

	public static void main(String[] args) 
	{
		String Name[] = new String[4];		 // tells system there will be 4 names in the array
		double Salary[] = new double[4];     // tells system there will be 4 salarys put into the array
		Scanner keyboard = new Scanner(System.in);
		int x=0;
		for (x=0; x < 4 ;x++)
			
	// Array loop to enter names and salarys of 4 employees
		{
			System.out.print("Please entger a name: ");
			Name[x] = keyboard.next();
			System.out.print("Please entger a Salary: ");
			Salary[x] = keyboard.nextDouble();
		}
		
		// Array loop to PRINT names and salarys of 4 employees
		for (x=0; x < 4 ;x++)
        {
    		System.out.println("Your Array contains: ");
	    	System.out.println(Name[x]);
	    	System.out.println("$ " + Salary[x]);
	    
		}
		
		// Calls AvgSal
		AvgSal(Name, Salary);  
		
		// Calls FindEmp
		FindEmp(Name, Salary);  
		
		
		
	}
	
	
	// Array loop that adds each employees salary to the total as it loops through
	
	public static void AvgSal (String N[], double S[])
	
	{
		double Total = 0.0;

		for (int x=0; x < 4 ;x++)
    {
		Total = Total + S[x];
    
	}
		double AvgSalary = Total / 4;
		System.out.println();
		
	// running total after array loop has completed
		System.out.println("The employees' total salary is: $" + Total );
	
	// Running total divided by 4 to output average salary of the 4 employees
		System.out.println("The employees' average salary is: $" + AvgSalary );
	
	}


	// Array loop that user searches for a name. 
	// Name is searched for by loop.
	// If name is found the rmployees name will be listed with their corresponding salary
	// If name is not found 
	
	public static int FindEmp (String N[] , double S[])
	{
		
		String Name = "";
		double Salary = 0.0;

		Scanner keyboard = new Scanner(System.in);
		System.out.print("Which employee do you wish to find?: ");
		Name = keyboard.next();
		
		
		for (int x = 0 ; x < 4  ;x++)
		{
			
		// if employee name is located 	
			if (Name.equals (N[x]))
				
		// if employee name is located 	this prints
		{
			System.out.println( Name + " located: " + " The employees salary is $" + S[x] );
			return x;
		}
			
			// if employee name NOT is located 	this prints	
			else
				System.out.println( Name + " Not located: "  );
			
		}
		return 0;
		}
	
	 
	
	{
		
	}
}
