// Ronald Russell
// Dr. Fay
// CIS 120
// You Do it Ch 3
// 2/26/2020


 public class SpaService
 { 
 
 

         //  variables 
    	 
     private String serviceDescription;
     private double price;
    	 
    
    	 
     public void setServiceDescription(String service)
    	 {
    	 serviceDescription = service;
    	 }
     
     public void setPrice(double servicePrice)
    	 {
    	 price = servicePrice;
    	 }
    	 
    
     public String getServiceDescription()
     	{
    	 return serviceDescription;
     	}
     
     public double getPrice()
     	{
    	 return price;
     	}
 
 } 
