// Ronald Russell
// Dr. Fay
// CIS 120
// Lab04
// 4/15/2020


package lab04;


public class MyDoggie 
{

	public static void main(String[] args) 
	{
	
		
	// Defines variables for MYDOGGI1-MYDOGGI4 with Dog name and Breed
		
		Doggie  MYDOGGI1 = new Doggie ("mona", "Mutt");
		Doggie  MYDOGGI2 = new Doggie ("Carmen" , "Austrialian Shepard Mix");
		Doggie  MYDOGGI3 = new Doggie ("Button" , "Terrier Mix");
		Doggie  MYDOGGI4 = new Doggie ("Max" ,"Miniture Chihuahua");
		

		// Defines Variables for  MYDOGGI1
		
		MYDOGGI1.setSex('F');
		MYDOGGI1.setBreed("Black Lab and Shepard Mix");
		MYDOGGI1.setColor("W");
		MYDOGGI1.setName("Mona");
		MYDOGGI1.setOwner("John and Fay");
		MYDOGGI1.setDOB("08/22/2010");
		
		// Defines Variables for  MYDOGGI2
		
		MYDOGGI2.setSex('F');
		MYDOGGI2.setBreed("Austrialian Shepard Mix");
		MYDOGGI2.setColor("Brown, grey, White, and Black");
		MYDOGGI2.setName("Carmen");
		MYDOGGI2.setOwner("Fay and John");
		MYDOGGI2.setDOB("08/22/2010");
		
		// Defines Variables for  MYDOGGI3
		
		MYDOGGI3.setSex('F');
		MYDOGGI3.setBreed("Terrier Mix");
		MYDOGGI3.setColor("Black");
		MYDOGGI3.setName("Button");
		MYDOGGI3.setOwner("John and Fay");
		MYDOGGI3.setDOB("09/22/2016");
		
		// Defines Variables for  MYDOGGI4
		
		MYDOGGI4.setSex('M');
		MYDOGGI4.setBreed("Miniture Chihuahua");
		MYDOGGI4.setColor("Golden Blonde");
		MYDOGGI4.setName("Max");
		MYDOGGI4.setOwner("Fay and John");
		MYDOGGI4.setDOB("08/22/2010");
		
		
		//Print output that calls the output data for MYDOGG1 along with 2 commands and responses from MYDOGG1
		
		MYDOGGI1.PrintDog();
		MYDOGGI1.DogSit();
		MYDOGGI1.DogFetch();

		//Print output that calls the output data for MYDOGG2 along with 2 commands and responses from MYDOGG2
		MYDOGGI2.PrintDog();
		MYDOGGI2.DogBark();
		MYDOGGI2.DogLay();

		//Print output that calls the output data for MYDOGG3 along with 2 commands and responses from MYDOGG3
		MYDOGGI3.PrintDog();
		MYDOGGI3.DogFetch();
		MYDOGGI3.DogBark();

		//Print output that calls the output data for MYDOGG4 along with 2 commands and responses from MYDOGG4
		MYDOGGI4.PrintDog();
		MYDOGGI4.DogSit();
		MYDOGGI4.DogLay();

	}

}
