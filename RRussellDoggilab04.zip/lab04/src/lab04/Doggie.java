// Ronald Russell
// Dr. Fay
// CIS 120
// Lab04
// 4/15/2020


package lab04;


// Set all variables to null

public class Doggie 

{
	String Name = "";
	String Owner = "";
	String Breed = "";
	String Color = "";
	String DOB = "";
	String TypeofFur = "";
	String Temperment = "";
	double Weight = 0.0;
	char Fixed = ' ';
	char Sex =' ';
	char Shedding =' ';
	
	Doggie()
	{
		Name = "";
		Breed = "";
		Color = "";
		DOB = "";
		TypeofFur = "";
		Temperment = "";
		Weight = 0.0;
		Fixed = ' ';
		Shedding =' ';
	}
	Doggie(String nameIn, String BreedIn)
	{
		Name = nameIn;
		Breed = BreedIn;
		Color = "";
		DOB = "";
		TypeofFur = "";
		Temperment = "";
		Weight = 0.0;
		Fixed = ' ';
		Shedding =' ';
	}

	
	// Define each variable for formatting
	
	public void setName(String DogName)
	{
		Name = DogName;
	}
	public void setBreed(String Breed1)
	{
		Breed = Breed1;
	}
	public void setSex(char s)
	{
		Sex = s;
	}
	public void setColor(String ColorP)
	{
		Color = ColorP;
	}
	public void setDOB(String BirthDay)
	{
		DOB = BirthDay;
	}
	public void setOwner(String OwnMe)
	{
		Owner = OwnMe;
	}
	

	// This will be the order set for the output as Dog name, Breed, Color, DOB, Sex, and Owner
	
	public void PrintDog()
	{
		System.out.println("-------------------------------------------- ");
		System.out.println(" ");
		System.out.println("Dog's Name: " + this.Name);
		System.out.print("Breed: ");
		System.out.println(this.Breed);
		System.out.println("Color Code: " + this.Color);
		System.out.println("DOB: " + this.DOB);

		System.out.println("Sex (x is fixed): " + this.Sex);
		System.out.println("Ower's Name: " + this.Owner);
		System.out.println(" ");

	}
	
	// Definitions for each Dog command with response
	
	//Call response for DogSit
	
	
	public void DogSit()
	{
			System.out.println("Sit dog!");
			System.out.println("Why don't you give me a treat first?");
			System.out.println(" ");
			System.out.println(" ");
			
	}
	
	//Call response for DogLay
	
	public void DogLay()
	{
			System.out.println("Lay down");
			System.out.println("SURE! I AM A HUGE BED HOG!");
			System.out.println(" ");
			
	}
	
	//Call response for DogBark
	
	public void DogBark()
	{
			System.out.println("Speak");
			System.out.println("WOOF!");
			System.out.println(" ");
			
	}
	
	//Call response for Dogfetch
	
	public void DogFetch()
	{
			System.out.println("Go get your ball!");
			System.out.println("I am tired. Maybe later");
			System.out.println(" ");
			
	}
}
	


