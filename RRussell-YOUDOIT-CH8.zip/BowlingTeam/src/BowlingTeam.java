// Ronald Russell
// Dr. Fay
// CIS 120
// you Do It ch 8
// 4/15/2020

public class BowlingTeam
{
	
	private String teamName;
	private String[] members = new String[4];
	
	public void setTeamName(String team)
	{
	   teamName = team;
	}
	public String getTeamName()
	{
	   return teamName;
	}
	
	public void setMember(int number, String name)
	{
	   members[number] = name;
	}
	
	public String getMember(int number)
	{
	   return members[number];
	}
}