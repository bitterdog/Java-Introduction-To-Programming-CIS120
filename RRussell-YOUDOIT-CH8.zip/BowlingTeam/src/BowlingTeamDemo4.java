// Ronald Russell
// Dr. Fay
// CIS 120
// you Do It ch 8
// 4/15/2020


import java.util.*;
public class BowlingTeamDemo4
{
   public static void main(String[] args)
   {
	   
	   /*
	    * five declarations. These include a String that holds user input, a
			BowlingTeam object, an integer to use as a subscript, a constant that
			represents the number of members on a bowling team, and a Scanner
			object for input
	    */
	   
	   String name;
	      final int NUM_TEAMS = 4;
	      BowlingTeam[] teams = new BowlingTeam[NUM_TEAMS];
	      int x;
	      int y;
	      final int NUM_TEAM_MEMBERS = 4;
	      Scanner input = new Scanner(System.in);
	      getTeamData(teams);
	      for(y = 0; y < NUM_TEAMS; ++y)
	      {
	         System.out.println("\nMembers of team " + teams[y].getTeamName());
	         for(x = 0; x < NUM_TEAM_MEMBERS; ++x)
	            System.out.print(teams[y].getMember(x) + "  ");
	         System.out.println();
	      }
	      //Prompt the user for a bowling team name
		   
		   /*
		    *  loop that executes four times, prompt the user for a team member�s
				name. Accept the name and assign it to the BowlingTeam object using
				the subscript to indicate the team member�s position in the array in the
				BowlingTeam class
		    */
	      
	      System.out.print("\n\nEnter a team name to see its roster >> ");
	      name = input.nextLine();
	      for(y = 0; y < teams.length; ++y)
	         if(name.equals(teams[y].getTeamName()))
	            for(x = 0; x < NUM_TEAM_MEMBERS; ++x)
	               System.out.print(teams[y].getMember(x) + "  ");
	      System.out.println(); 
	   }
	   public static void getTeamData(BowlingTeam[] teams)
	   {
	      String name;
	      final int NUM_TEAMS = 4;
	      int x;
	      int y;
	      final int NUM_TEAM_MEMBERS = 4;
	      Scanner input = new Scanner(System.in);
	      for(y = 0; y < NUM_TEAMS; ++y)
	      {
	        teams[y] = new BowlingTeam();
	        System.out.print("Enter team name >> ");
	        name = input.nextLine();
	        teams[y].setTeamName(name);
	        for(x = 0; x < NUM_TEAM_MEMBERS; ++x)
	        {
	           System.out.print("Enter team member's name >> ");
	           name = input.nextLine();
	           teams[y].setMember(x, name);
	           
	        }
	      }
	   }
}
