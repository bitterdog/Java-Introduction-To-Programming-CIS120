// Ronald Russell
// Dr. Fay
// CIS 120
// you Do It ch 8
// 4/15/2020


public class DemoArray2
{
   public static void main(String[] args)
   {
	   //declare and create an array that can hold four double values
	   double[] salaries = {12.25, 13.55, 14.25, 16.85};
	   
	   //One by one, assign four values to the four array elements 		
		   salaries[0] = 12.25;
		   salaries[1] = 13.55;
		   salaries[2] = 14.25;
		   salaries[3] = 16.85;
	   		
	   // display the salaries one by one 		
		   System.out.println("Salaries one by one are:");
		   System.out.println(salaries[0]);
		   System.out.println(salaries[1]);
		   System.out.println(salaries[2]);
		   System.out.println(salaries[3]);
		   
   }
}