// Ronald Russell
// Dr. Fay
// CIS 120
// you Do It ch 3
// 3/2/2020


public class TestInfo
{
	public static void main(String[] args)
	{
		System.out.println("Calling method from another class:");
		ParadiseInfo.displayInfo();
	}
}