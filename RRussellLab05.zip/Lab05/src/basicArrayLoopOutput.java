import java.util.Random;
import java.util.Scanner;


public class basicArrayLoopOutput
{

	


	public static void main(String[] args)
	{


		basicArrayLoopOutput();


	}
	
	// This is a basic array that predefines 3 variables as nums[0], nums[1], and nums[2] and assigns each a value
	// and then outputs the 3 variable to the console

	public static void basicArrayLoopOutput()
	{
		// Assigns 3 variables and defines each variable with a value "number"
		int[] nums = new int[3];

		nums[0] = 3;

		nums[1] = 6;

		nums[2] = 9;

		System.out.println("values in nums array");

		for (int i = 0; i < nums.length; i++)

			System.out.println(nums[i]);

	}
}