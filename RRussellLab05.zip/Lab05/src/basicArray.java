import java.util.*;

// This is a basic array that predefines 2 variables as names[0] and names[1] and assigns each a value
// and then outputs the 2 variable to the console


public class basicArray
{



	public static void main(String[] args)
	{

		basicArray();

	}

	public static void basicArray()
	{

		// Assigns 2 variables and defines each variable with a value "name"
		String[] names = new String[2];

		names[0] = "Matt";

		names[1] = "Laura";

		System.out.println("values in names array");

		System.out.println(names[0]);

		System.out.println(names[1]);

	}
}