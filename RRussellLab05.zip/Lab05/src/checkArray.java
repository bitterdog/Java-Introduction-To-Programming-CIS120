import java.util.Random;
import java.util.Scanner;


public class checkArray
{

	
	public static Random randy = new Random();

	public static Scanner keyboard = new Scanner(System.in);


	public static void main(String[] args)
	{

		checkArray();

	}

	// Array stores a list of Area codes and requires a user input to search for a area code
	// If the Area code is in the array it gives you the corresponding slot that the Area code is in the list.
	
	public static void checkArray()
	{

		String[] areaCodes = {"928", "320", "307"};

		System.out.print("Enter an area code: ");

		String userCode = keyboard.nextLine();

		int i = 0;

		for (; i < areaCodes.length; i++)

		{

			if (userCode.equals(areaCodes[i]))
			{

				System.out.print("area code " + userCode + " was found at the " + i + " spot.");

				i = areaCodes.length + 1;		

			}
			
		}
		
		if (i == areaCodes.length)

			System.out.println("Sorry, " + userCode + " wasn't found in the array.");

	}
}