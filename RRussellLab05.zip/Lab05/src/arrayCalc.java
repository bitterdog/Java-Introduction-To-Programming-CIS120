import java.util.Random;
import java.util.Scanner;


public class arrayCalc
{

	
	public static Random randy = new Random();

	public static Scanner keyboard = new Scanner(System.in);


	public static void main(String[] args)
	{


		arrayCalc();



	}


// Array holds 3 numbers , adds the numbers together and divides the total by the number of numbers
	public static void arrayCalc()
	{
		int[] nums = {15, 20, 25};

		int sum = 0;

		for (int i = 0; i < nums.length; i++)

			sum = sum + nums[i];

		double average = (double) sum/nums.length;

		System.out.println("the sum of the numbers in the array is " + sum);

		System.out.println("the average of the numbers in the array is " + average); 


	}
}