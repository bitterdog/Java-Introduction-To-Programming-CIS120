import java.util.*;


public class Lab05
{

	
	public static Random randy = new Random();

	public static Scanner keyboard = new Scanner(System.in);


	public static void main(String[] args)
	{

		//basicArray();

		//basicArrayLoopOutput();

		//basicArrayLoopIO();

		//basicArrayUserSizeIO();

		//arrayDecAndAssign();

		//arrayCalc();

		//checkArray();

		//ParArrayItemShop();

		arrayDecAndAssign();


	}

	public static void basicArray()
	{

		String[] names = new String[2];

		names[0] = "Matt";

		names[1] = "Laura";

		System.out.println("values in names array");

		System.out.println(names[0]);

		System.out.println(names[1]);

	}

	public static void basicArrayLoopOutput()
	{

		int[] nums = new int[3];

		nums[0] = 3;

		nums[1] = 6;

		nums[2] = 9;

		System.out.println("values in nums array");

		for (int i = 0; i < nums.length; i++)

			System.out.println(nums[i]);

	}

	public static void basicArrayLoopIO()
	{


		String[] fruit = new String[4];

		for (int i = 0; i < fruit.length; i++)
		{
			System.out.print("enter fruit " + (i+1) + ": ");

			fruit[i] = keyboard.nextLine();

		}

		System.out.println("Your list contains");

		for (int i = 0; i < fruit.length; i++)
			
			System.out.println(fruit[i]);

	}

	public static void basicArrayUserSizeIO()
	{

		System.out.print("How many double values would you like to enter: ");

		int arraySize = keyboard.nextInt();
		
		keyboard.nextLine();

		double[] values = new double[arraySize];

		for (int i = 0; i < arraySize; i++)
		{
		
			System.out.print("Enter value " + (i+1) + ": ");

			values[i] = keyboard.nextDouble();

			keyboard.nextLine();
	
		}

		System.out.println("Your list contains");

		for (int i = 0; i < arraySize; i++)

			System.out.println(values[i]);

		
	}

	public static void arrayDecAndAssign()
	{

		String[] names = {"Jim", "Bob", "Susie", "Sharon"};

		System.out.println("values in names array");

		for (int i = 0; i < names.length; i++)

			System.out.print(names[i]);

	}

	public static void arrayCalc()
	{
		int[] nums = {15, 20, 25};

		int sum = 0;

		for (int i = 0; i < nums.length; i++)

			sum = sum + nums[i];

		double average = (double) sum/nums.length;

		System.out.println("the sum of the numbers in the array is " + sum);

		System.out.println("the average of the numbers in the array is " + average); 


	}

	public static void checkArray()
	{

		String[] areaCodes = {"928", "320", "307"};

		System.out.print("Enter an area code: ");

		String userCode = keyboard.nextLine();

		int i = 0;

		for (; i < areaCodes.length; i++)

		{

			if (userCode.equals(areaCodes[i]))
			{

				System.out.print("area code " + userCode + " was found at the " + i + " spot.");

				i = areaCodes.length + 1;		

			}
			
		}
		
		if (i == areaCodes.length)

			System.out.println("Sorry, " + userCode + " wasn't found in the array.");

	}
	

	public static void ParArrayItemShop()
	{

		String[] items = {"sword", "shield", "potion"};

		int[] prices= {25, 40, 10};

		int gold = 100;

		System.out.println("Store inventory");

		for (int i = 0; i< items.length; i++)

			System.out.println(items[i] + "  " + prices[i]);

		System.out.println();

		String response = "";
	

		do
		{
			System.out.print("Would you like to purchase anything?  You have " + gold + " gold (y to buy) :");

			response = keyboard.nextLine();

			if (response.equals("y") || response.equals("Y"))
			{
				System.out.print("what would like to buy? ");

				String userItem = keyboard.nextLine();

				int i=0;

				for( ; i< items.length; i++)
				{

					if(userItem.equals(items[i]))
					{
				
						if ( gold >= prices[i])
						{
						
							System.out.println("you bought a " + items[i]);
							
							gold = gold - prices[i];

						}
						else
							System.out.println("sorry, you don't have enough gold.");	

						i = items.length + 1;

					}

				}

				if (i == items.length)
					System.out.println("Sorry, we don't carry that item.");

			}
			
			
			

		} while(response.equals("y") || response.equals("Y"));

	

	}

	/************************************************************************************
		 			(Guess the capitals game) 
		 This program  repeatedly prompts the user to enter 
		 a capital for a state. The program reports whether the answer is correct.                            
	************************************************************************************/
	

	public static void stateCapsGame()
	{

		String[] states = new String[50];

		String[] capitals = new String[50];

		populate(states, capitals);

		String playAgain = "";

		do
		{
			System.out.println();
			
			play(states, capitals);
			
			System.out.print("Play again? y for yes, anything else to quit.");

			playAgain = keyboard.nextLine();

		}  while (playAgain.equals("y") || playAgain.equals("Y"));

	}

	public static void play(String[] states, String[] capitals)
	{
		int rand = randy.nextInt(50);

		System.out.print("What is the capital of " + states[rand] + " ");

		String userAnswer = keyboard.nextLine();

		System.out.println();

		if (userAnswer.equals(capitals[rand]))
				
			System.out.println("Excellent!  " + userAnswer + " is correct.");

		else
			System.out.println("Sorry, the correct answer is " + capitals[rand]);

		System.out.println();

	}


	public static void populate(String[] states, String[] capitals)
	{
			
		states[0] = "Alabama";  //states[0] and capitals[0] have parallel information
       		capitals[0] = "Montgomery";  //Montgomery is the capital of Alabama - both have index 0
       		states[1] = "Alaska";
       		capitals[1] = "Juneau";
       		states[2] = "Arizona";
     		capitals[2] = "Phoenix";
      		states[3] = "Arkansas";
     		capitals[3] = "Little Rock";
     		states[4] = "California";
        	capitals[4] = "Sacramento";
        	states[5] = "Colorado";
        	capitals[5] = "Denver";
        	states[6] = "Connecticut";
        	capitals[6] = "Hartford";
        	states[7] = "Delaware";
        	capitals[7] = "Dover";
        	states[8] = "Florida";
        	capitals[8] = "Tallahassee";
        	states[9] = "Georgia";
        	capitals[9] = "Atlanta";
        	states[10] = "Hawaii";
        	capitals[10] = "Honolulu";
        	states[11] = "Idaho";
        	capitals[11] = "Boise";
        	states[12] = "Illinois";
        	capitals[12] = "Springfield";
        	states[13] = "Indiana";
        	capitals[13] = "Indianapolis";
        	states[14] = "Iowa";
        	capitals[14] = "Des Moines";
        	states[15] = "Kansas";
        	capitals[15] = "Topeka";
       		states[16] = "Kentucky";
       		capitals[16] = "Frankfort";
       		states[17] = "Louisana";
       		capitals[17] = "Baton Rouge";
       		states[18] = "Maine";
       		capitals[18] = "Augusta";
       		states[19] = "Maryland";
       		capitals[19] = "Annapolis";        		
		states[20] = "Massachusetts";
        	capitals[20] = "Boston";
        	states[21] = "Michigan";
        	capitals[21] = "Lansing";
        	states[22] = "Minnesota";
        	capitals[22] = "Saint Paul";
        	states[23] = "Mississippi";
        	capitals[23] = "Jackson";
        	states[24] = "Missouri";
        	capitals[24] = "Jefferson City";
        	states[25] = "Montana";
        	capitals[25] = "Helena";
        	states[26] = "Nebraska";
        	capitals[26] = "Lincoln";
        	states[27] = "Nevada";
        	capitals[27] = "Carson City";
        	states[28] = "New Hampshire";
        	capitals[28] = "Concord";
        	states[29] = "New Jersey";
        	capitals[29] = "Trenton";
        	states[30] = "New Mexico";
        	capitals[30] = "Santa Fe";
        	states[31] = "New York";
        	capitals[31] = "Albany";
        	states[32] = "North Carolina";
        	capitals[32] = "Raleigh";
        	states[33] = "North Dakota";
        	capitals[33] = "Bismarck";
        	states[34] = "Ohio";
        	capitals[34] = "Columbus";
        	states[35] = "Oklahoma";
        	capitals[35] = "Oklahoma City";
        	states[36] = "Oregon";
        	capitals[36] = "Salem";
        	states[37] = "Pennsylvania";
        	capitals[37] = "Harrisburg";
        	states[38] = "Rhode Island";
        	capitals[38] = "Providence";
        	states[39] = "South Carolina";
        	capitals[39] = "Columbia";
        	states[40] = "South Dakota";
        	capitals[40] = "Pierre";
        	states[41] = "Tennessee";
        	capitals[41] = "Nashville";
        	states[42] = "Texas";
        	capitals[42] = "Austin";
        	states[43] = "Utah";
        	capitals[43] = "Salt Lake City";
        	states[44] = "Vermont";
        	capitals[44] = "Montpelier";
        	states[45] = "Virginia";
        	capitals[45] = "Richmond";
        	states[46] = "Washington";
        	capitals[46] = "Olympia";
        	states[47] = "West Virginia";
        	capitals[47] = "Charleston";
        	states[48] = "Wisconsin";
        	capitals[48] = "Madison";
        	states[49] = "Wyoming";
        	capitals[49] = "Cheyenne";


	}




}