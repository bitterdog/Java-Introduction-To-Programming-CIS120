import java.util.Random;
import java.util.Scanner;


public class arrayDecAndAssign
{

	public static Random randy = new Random();

	public static Scanner keyboard = new Scanner(System.in);


	public static void main(String[] args)
	{
		arrayDecAndAssign();

	}
	// Array list of names output 
		public static void arrayDecAndAssign()
		{
	
			String[] names = {"Jim ", "Bob ", "Susie ", "Sharon "};
	
			System.out.println("values in names array");
	
			for (int i = 0; i < names.length; i++)
	
				System.out.print(names[i]);

	}
}
