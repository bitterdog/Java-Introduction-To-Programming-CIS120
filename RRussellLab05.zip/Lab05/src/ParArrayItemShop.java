import java.util.Random;
import java.util.Scanner;


public class ParArrayItemShop
{

	
	public static Random randy = new Random();

	public static Scanner keyboard = new Scanner(System.in);


	public static void main(String[] args)
	{
		ParArrayItemShop();
	}

	// This array stores an item number and assigns a fixed value to that item
	// The user is given 100 gold at the start and is asked if they wish to purchase an item
	// If the user chooses yes, they will be promted for the item name they wish to purchase.
	// The fixed value of that item chosen will be deducted from their running total as long as gold>0 and items is a valid item 
	// in the array. Loop will continue until User no longer wishes to purchase an Item or they do not have enough gold to make a purchase
	
	public static void ParArrayItemShop()
	{

		String[] items = {"sword", "shield", "potion"};

		int[] prices= {25, 40, 10};

		int gold = 100;

		System.out.println("Store inventory");

		for (int i = 0; i< items.length; i++)

			System.out.println(items[i] + "  " + prices[i]);

		System.out.println();

		String response = "";
	

		do
		{
			System.out.print("Would you like to purchase anything?  You have " + gold + " gold (y to buy) :");

			response = keyboard.nextLine();

			if (response.equals("y") || response.equals("Y"))
			{
				System.out.print("what would like to buy? ");

				String userItem = keyboard.nextLine();

				int i=0;

				for( ; i< items.length; i++)
				{

					if(userItem.equals(items[i]))
					{
				
						if ( gold >= prices[i])
						{
						
							System.out.println("you bought a " + items[i]);
							
							gold = gold - prices[i];

						}
						else
							System.out.println("sorry, you don't have enough gold.");	

						i = items.length + 1;

					}

				}

				if (i == items.length)
					System.out.println("Sorry, we don't carry that item.");

			}
			
			
			

		} while(response.equals("y") || response.equals("Y"));

	

	}
}