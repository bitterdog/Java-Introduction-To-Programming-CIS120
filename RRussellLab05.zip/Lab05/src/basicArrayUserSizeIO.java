import java.util.Random;
import java.util.Scanner;


public class basicArrayUserSizeIO
{


	public static Scanner keyboard = new Scanner(System.in);


	public static void main(String[] args)
	{

		basicArrayUserSizeIO();


	}


	public static void basicArrayUserSizeIO()
	{

		// in this array the user defines how big the array will be , then runs the loop x amount of times accepting user input 
		// then lists the output of the array
		System.out.print("How many double values would you like to enter: ");

		int arraySize = keyboard.nextInt();
		
		keyboard.nextLine();

		double[] values = new double[arraySize];

		for (int i = 0; i < arraySize; i++)
		{
		
			System.out.print("Enter value " + (i+1) + ": ");

			values[i] = keyboard.nextDouble();

			keyboard.nextLine();
	
		}

		System.out.println("Your list contains");

		for (int i = 0; i < arraySize; i++)

			System.out.println(values[i]);

		
	}
}