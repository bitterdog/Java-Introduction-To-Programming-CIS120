import java.util.Random;
import java.util.Scanner;


public class basicArrayLoopIO
{

	


	public static Scanner keyboard = new Scanner(System.in);


	public static void main(String[] args)
	{

		basicArrayLoopIO();

	}


	public static void basicArrayLoopIO()
	{

		// This is the loop that builds the array with the input by the user of 4 fruits. 
		
		String[] fruit = new String[4];
		
		// for each input the loop number is assigned to the fruit name that the user input
		// Example you are entering your 3rd fruit so you are on loop #3 
		// that would be put into the array as fruit[3]="whatever fruit name you entered"

		for (int i = 0; i < fruit.length; i++)
		{
			System.out.print("enter fruit " + (i+1) + ": ");

			fruit[i] = keyboard.nextLine();

		}

		System.out.println("Your list contains");

		for (int i = 0; i < fruit.length; i++)
			
			System.out.println(fruit[i]);

	}
}