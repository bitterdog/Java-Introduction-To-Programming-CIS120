// Ronald Russell
// Dr. Fay
// CIS 120
// you Do It ch 6
// 4/15/2020


public class DemoIncrement 

{

	public static void main(String[] args) {
		// Define Variables
		//declare variable named plusPlusV and assign it a value of ++v
		int v = 4;
		int plusPlusV = ++v;
		
		// reset v to 4 
		v = 4;
		int vPlusPlus = v++;
		
		//display the three values
		System.out.println("v is " + v);
		System.out.println("++v is " + plusPlusV);
		System.out.println("v++ is " + vPlusPlus);

	}

}
