// Ronald Russell
// Dr. Fay
// CIS 120
// you Do It ch 5
// 4/15/2020

import java.util.Scanner;


public class AssignVolunteer
{
 public static void main(String[] args)
 {
	 
	  // Define variables
	 int donationType;
	 String volunteer;
	 
	// assign  variable name to item #
	 final int CLOTHING_CODE = 1;
	 final int OTHER_CODE = 2;
	 
	// assign Product pricer with employee name
	 final String CLOTHING_PRICER = "Regina";
	 final String OTHER_PRICER = "Marco";
	 
	  // User input of donation type    
	  // Begin Loop
	 Scanner input = new Scanner(System.in);
	 System.out.println("What type of donation is this?");
	 System.out.print("Enter " + CLOTHING_CODE + " for clothing, " +
	  OTHER_CODE + " for anything else� ");
	 donationType = input.nextInt();
	 
	 
	  // Validation check
	 if(donationType == CLOTHING_CODE)
		 volunteer = CLOTHING_PRICER;
		else
		 volunteer = OTHER_PRICER;
	 
	 
	  // Ouput to screen
	 System.out.println("You entered " + donationType);
	 System.out.println("The volunteer who will price this item is " +
	  volunteer);
	 
 }
 
}