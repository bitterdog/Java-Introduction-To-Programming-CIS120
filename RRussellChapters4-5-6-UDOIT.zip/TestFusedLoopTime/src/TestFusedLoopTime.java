// Ronald Russell
// Dr. Fay
// CIS 120
// you Do It ch 6
// 4/15/2020


import java.time.*;

public class TestFusedLoopTime

{
 public static void main(String[] args) 
 
{	
	 // variables to hold starting and ending times for loop execution
	 	int startTime, endTime;
	 	
	 // loop control variable
	 	int x;
	 //two named constants that hold a number of times to repeat loops and a factor for converting nanoseconds to milliseconds
		 final int REPEAT = 5_000_000;
		 final int FACTOR = 1_000_000;
	 
	 //LocalDateTime object, initialize it to a starting time, and extract its nanoseconds component
		 LocalDateTime now;
		 now = LocalDateTime.now();
		 startTime = now.getNano();
		 
		 // loop that repeats 5 million times
			 for(x = 0; x < REPEAT; ++x)
				 method1();
				for(x = 0; x < REPEAT; ++x)
				 method2();
			
		/*When both loops are finished, get the current time, extract the nanoseconds
		value, and display the difference between the start time and the end time,
		expressed in milliseconds:
		 */
				now = LocalDateTime.now();
				endTime = now.getNano();
				System.out.println("Time for loops executed separately: " +
				 ((endTime - startTime) / FACTOR) + " milliseconds");
				
		//Get a new starting time, and call method1() and method2() 5 million times each, blocked in a single loop.
				now = LocalDateTime.now();
				startTime = now.getNano();
				for(x = 0; x < REPEAT; ++x)
				{
				 method1();
				 method2();
				}
				
		//Get the ending time for the loop, and display the value of the elapsed interval.
				now = LocalDateTime.now();
				 endTime = now.getNano();
				 System.out.println("Time for loops executed in a block: " +
				 ((endTime - startTime) / FACTOR) + " milliseconds");
				}
 
 		//two methods named method1() and method2()
				 public static void method1()
				 {
				 }
				 public static void method2()
				 {
 }


	}


