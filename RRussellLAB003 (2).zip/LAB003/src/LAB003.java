

import java.util.*;
public class LAB003
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		// Declare variables
		int NumOfQuestions=0;
		int X = 0;
		int Y = 0;
		int Operator = 0;
		int ANS = 0;
		int ANSUser;
		
		// Keyboard input number of questions
		Random r = new Random();
		Scanner Keyboard = new Scanner(System.in);
		System.out.println("How many questions would you like to answer ? ");
		NumOfQuestions = Keyboard.nextInt();
		
		
		// Loop number of questions 		
		
			for (int i=0; i<NumOfQuestions; i++)

					{
					    Operator = r.nextInt(3 + 1)+1;
			
						switch (Operator)
						
						
							{
							
			
									
							case 3:
								System.out.println("Question #" + (i));
							X = r.nextInt(9+1)+1;
							Y = r.nextInt(9+1)+1;
							ANS = X * Y;
							System.out.println(X + " * " + Y + " = " + "?");
							ANSUser = Keyboard.nextInt();
							if (ANSUser == ANS)
							
								
							// Is the answer correct?
							{
								System.out.println("Great! Your correct!");
								System.out.println(X + " * " + Y + " = " + ANS);
								break;
							}
							
							
							// Is the answer wrong?
							else
							{
								System.out.println("Your wrong! :(");
								System.out.println(X + " * " + Y + " = " + ANS);
								break;
							}
							
						
							
							
							
							case 2:
								System.out.println("Question #" + (i));
							X = r.nextInt(9+1)+1;
							Y = r.nextInt(9+1)+1;
							ANS = X - Y;
							
							System.out.println(X + " - " + Y + " = " + "?");
							ANSUser = Keyboard.nextInt();
							if (ANSUser == ANS)
								
								// Is the answer correct?
							{
								System.out.println("Great! Your correct!");
								System.out.println(X + " - " + Y + " = " + ANS);
								break;
							}
							
							// Is the answer wrong?
							else
							{
								System.out.println("Your wrong! :(");
								System.out.println(X + " - " + Y + " = " + ANS);
								break;
							}
						
						
							
							
							
							case 1:
								System.out.println("Question #" + (i));
							X = r.nextInt(9+1)+1;
							Y = r.nextInt(9+1)+1;
							ANS = X + Y;
							System.out.println(X + " + " + Y + " = " + "?");
							ANSUser = Keyboard.nextInt();
							if (ANSUser == ANS)
								
							
								// Is the answer correct?
							{
								System.out.println("Great! Your correct!");
								System.out.println(X + " + " + Y + " = " + ANS);
								break;
							}
							
							// Is the answer wrong?
							else
							{
								System.out.println("Your wrong! :(");
								System.out.println(X + " + " + Y + " = " + ANS);
								break;
							}
					}

	}

}
}
